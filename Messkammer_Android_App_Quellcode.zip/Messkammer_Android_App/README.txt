MESSKAMMER BLUETOOTH – ANDROID-APP (Projekt zum APK-Bauen)
===========================================================

Die App zeigt die drei Messwerte deiner vorhandenen Firmware
ES3C28P_Messkammer_V9_WLAN_Bluetooth.ino an:
  Temperatur (°C), relative Luftfeuchtigkeit (% rF), aw-Schätzung.

Verwendet Bluetooth Low Energy (BLE), kein WLAN und kein Internet.
Gerät: Messkammer-ES3C28P.
Die passende V9-Firmware liegt außerdem im Ordner ESP32_Firmware.
Dienst: d7ae1000-d923-4d21-9842-3e8949210000
Merkmale:
  Temperatur d7ae1001-d923-4d21-9842-3e8949210000
  Feuchte    d7ae1002-d923-4d21-9842-3e8949210000
  aw         d7ae1003-d923-4d21-9842-3e8949210000

APK ERSTELLEN (Windows-PC mit Android Studio):
1. Android Studio installieren: https://developer.android.com/studio
2. ZIP-Datei entpacken.
3. In Android Studio über 'Open' den Ordner Messkammer_Android_App öffnen.
4. Bei Bedarf 'Sync Project with Gradle Files' und SDK 35 installieren lassen.
5. Menü Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Danach liegt die Datei unter app/build/outputs/apk/debug/app-debug.apk.
7. APK auf Android-Handy übertragen und installieren.
   Falls Android warnt: Nur diese selbst gebaute Datei zur Installation zulassen.
8. Am Handy Bluetooth einschalten. In der App auf 'Bluetooth verbinden' tippen
   und bei Nachfrage 'Geräte in der Nähe' zulassen.

ALTERNATIVE ÜBER GITHUB ACTIONS:
Die Datei .github/workflows/android-apk.yml baut das APK automatisch,
sobald der Projektinhalt in einem eigenen GitHub-Repository liegt.
Unter Actions > Messkammer APK bauen > Run workflow kann ein Build gestartet werden.
Das Ergebnis ist als Artefakt 'Messkammer-Bluetooth-APK' zu finden.

HINWEISE:
- Dies ist der vollständige Android-Studio-Quellcode, KEINE fertige APK.
- Die App ist mit minSdk 26, targetSdk 35, Java 17 konfiguriert.
- Bluetooth-Berechtigungen für Android 12 und neuer sind enthalten.
- Der aw-Wert ist eine Schätzung aus der rF, keine verifizierte Messung der
  Wasseraktivität eines Lebensmittels.
- Code und Installation wurden hier nicht auf einem Android-Gerät getestet.
