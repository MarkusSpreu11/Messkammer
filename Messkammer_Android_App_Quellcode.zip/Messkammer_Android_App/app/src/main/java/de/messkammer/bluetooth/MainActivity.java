package de.messkammer.bluetooth;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Native Bluetooth-LE-Anzeige für ES3C28P_Messkammer_V9_WLAN_Bluetooth.ino.
 * Die ESP32-Werte sind UTF-8-Zeichenketten; kein WLAN und kein Internet nötig.
 */
public final class MainActivity extends Activity {
    private static final String DEVICE_NAME = "Messkammer-ES3C28P";
    private static final UUID SERVICE_UUID = UUID.fromString("d7ae1000-d923-4d21-9842-3e8949210000");
    private static final UUID TEMP_UUID = UUID.fromString("d7ae1001-d923-4d21-9842-3e8949210000");
    private static final UUID HUM_UUID = UUID.fromString("d7ae1002-d923-4d21-9842-3e8949210000");
    private static final UUID AW_UUID = UUID.fromString("d7ae1003-d923-4d21-9842-3e8949210000");
    private static final UUID CCC_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private static final int REQUEST_PERMISSIONS = 44;
    private static final int REQUEST_ENABLE_BLUETOOTH = 45;
    private static final long SCAN_DURATION_MS = 18_000L;

    private static final int BG = Color.rgb(11, 21, 35);
    private static final int PANEL = Color.rgb(21, 36, 55);
    private static final int OUTLINE = Color.rgb(46, 70, 86);
    private static final int LIGHT = Color.rgb(243, 249, 254);
    private static final int MUTED = Color.rgb(160, 184, 198);
    private static final int CYAN = Color.rgb(80, 229, 211);
    private static final int GREEN = Color.rgb(136, 230, 172);
    private static final int YELLOW = Color.rgb(255, 208, 135);
    private static final int RED = Color.rgb(255, 136, 136);

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private volatile BluetoothGatt gatt;
    private boolean scanning = false;
    private volatile boolean connected = false;
    private long lastValueAt = 0;
    private final ArrayList<BluetoothGattCharacteristic> measurements = new ArrayList<>();
    private int subscribePosition = 0;
    private int readPosition = 0;

    private TextView statusText;
    private TextView statusIcon;
    private TextView tempValue;
    private TextView humValue;
    private TextView awValue;
    private TextView updatedText;
    private Button connectButton;
    private Button disconnectButton;

    private final Runnable scanTimeout = () -> {
        if (scanning) {
            stopScan();
            setStatus("Keine Messkammer gefunden · erneut versuchen", false);
        }
    };

    private final Runnable staleWatchdog = new Runnable() {
        @Override public void run() {
            if (connected && lastValueAt > 0 && SystemClock.elapsedRealtime() - lastValueAt > 12_000L) {
                updatedText.setText("Seit über 12 Sekunden keine Messwerte empfangen");
            }
            mainHandler.postDelayed(this, 4_000L);
        }
    };

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            if (!scanning || result == null || result.getDevice() == null) return;
            BluetoothDevice found = result.getDevice();
            stopScan();
            setStatus("Messkammer gefunden · verbinde …", false);
            try {
                closeGatt();
                gatt = found.connectGatt(MainActivity.this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            } catch (SecurityException | IllegalStateException ex) {
                setStatus("Bluetooth-Verbindung nicht möglich", false);
            }
        }

        @Override public void onScanFailed(int errorCode) {
            runOnUiThread(() -> {
                stopScan();
                setStatus("Bluetooth-Suche fehlgeschlagen (" + errorCode + ")", false);
            });
        }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt current, int status, int newState) {
            if (current != gatt) {
                try { current.close(); } catch (Exception ignored) { }
                return;
            }
            if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                connected = true;
                runOnUiThread(() -> setStatus("Verbunden · lese Sensorwerte …", true));
                try {
                    if (!current.discoverServices()) {
                        runOnUiThread(() -> setStatus("Bluetooth-Dienste nicht verfügbar", false));
                    }
                } catch (SecurityException e) {
                    runOnUiThread(() -> setStatus("Bluetooth-Berechtigung fehlt", false));
                }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                if (current == gatt) {
                    connected = false;
                    gatt = null;
                    try { current.close(); } catch (Exception ignored) { }
                    runOnUiThread(() -> {
                        clearMeasurements();
                        setStatus("Verbindung getrennt · erneut verbinden", false);
                    });
                }
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt current, int status) {
            if (current != gatt) return;
            if (status != BluetoothGatt.GATT_SUCCESS) {
                runOnUiThread(() -> setStatus("Bluetooth-Dienste nicht lesbar", false));
                return;
            }
            BluetoothGattService service = current.getService(SERVICE_UUID);
            if (service == null) {
                runOnUiThread(() -> setStatus("Die V9-Bluetooth-INO wurde nicht gefunden", false));
                return;
            }
            measurements.clear();
            for (UUID id : Arrays.asList(TEMP_UUID, HUM_UUID, AW_UUID)) {
                BluetoothGattCharacteristic ch = service.getCharacteristic(id);
                if (ch != null) measurements.add(ch);
            }
            if (measurements.size() != 3) {
                runOnUiThread(() -> setStatus("Nicht alle drei Messwerte verfügbar", false));
                return;
            }
            subscribePosition = 0;
            subscribeNext(current);
        }

        @Override public void onDescriptorWrite(BluetoothGatt current, BluetoothGattDescriptor descriptor, int status) {
            if (current == gatt) subscribeNext(current);
        }

        // API 33+: die vom System gelieferte Kopie der Nutzdaten verwenden.
        @Override public void onCharacteristicChanged(BluetoothGatt current, BluetoothGattCharacteristic ch, byte[] value) {
            if (current == gatt) receive(ch.getUuid(), value);
        }

        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicChanged(BluetoothGatt current, BluetoothGattCharacteristic ch) {
            if (Build.VERSION.SDK_INT < 33 && current == gatt) receive(ch.getUuid(), ch.getValue());
        }

        @Override public void onCharacteristicRead(BluetoothGatt current, BluetoothGattCharacteristic ch, byte[] value, int status) {
            if (current != gatt) return;
            if (status == BluetoothGatt.GATT_SUCCESS) receive(ch.getUuid(), value);
            readNext(current);
        }

        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicRead(BluetoothGatt current, BluetoothGattCharacteristic ch, int status) {
            if (Build.VERSION.SDK_INT < 33 && current == gatt) {
                if (status == BluetoothGatt.GATT_SUCCESS) receive(ch.getUuid(), ch.getValue());
                readNext(current);
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        try {
            BluetoothManager manager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
            adapter = manager == null ? null : manager.getAdapter();
        } catch (Exception ex) {
            adapter = null;
        }
        makeUi();
        mainHandler.postDelayed(staleWatchdog, 4_000L);
        if (adapter == null) setStatus("Dieses Handy unterstützt kein Bluetooth", false);
    }

    @Override protected void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        stopScan();
        closeGatt();
        super.onDestroy();
    }

    private boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void beginConnect() {
        if (adapter == null) {
            setStatus("Bluetooth ist auf diesem Handy nicht verfügbar", false);
            return;
        }
        if (!hasPermissions()) {
            if (Build.VERSION.SDK_INT >= 31) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_PERMISSIONS);
            } else {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_PERMISSIONS);
            }
            return;
        }
        try {
            if (!adapter.isEnabled()) {
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_ENABLE_BLUETOOTH);
                return;
            }
            startScan();
        } catch (SecurityException ex) {
            setStatus("Bitte Bluetooth-Berechtigung erteilen", false);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            if (hasPermissions()) beginConnect();
            else setStatus("Bitte 'Geräte in der Nähe' erlauben", false);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BLUETOOTH) {
            if (resultCode == RESULT_OK) beginConnect();
            else setStatus("Bluetooth ist ausgeschaltet", false);
        }
    }

    private void startScan() {
        if (scanning) stopScan();
        if (connected) return;
        try {
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) {
                setStatus("Bluetooth-Suche steht nicht zur Verfügung", false);
                return;
            }
            scanning = true;
            clearMeasurements();
            setStatus("Suche Messkammer-ES3C28P …", false);
            List<ScanFilter> filters = Arrays.asList(
                    new ScanFilter.Builder().setServiceUuid(new ParcelUuid(SERVICE_UUID)).build(),
                    new ScanFilter.Builder().setDeviceName(DEVICE_NAME).build());
            ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            scanner.startScan(filters, settings, scanCallback);
            mainHandler.postDelayed(scanTimeout, SCAN_DURATION_MS);
        } catch (SecurityException | IllegalStateException ex) {
            scanning = false;
            setStatus("Bluetooth-Suche konnte nicht starten", false);
        }
    }

    private void stopScan() {
        mainHandler.removeCallbacks(scanTimeout);
        if (scanning && scanner != null) {
            try { scanner.stopScan(scanCallback); } catch (Exception ignored) { }
        }
        scanning = false;
        scanner = null;
    }

    private void closeGatt() {
        BluetoothGatt old = gatt;
        gatt = null;
        connected = false;
        if (old != null) {
            try { old.disconnect(); } catch (Exception ignored) { }
            try { old.close(); } catch (Exception ignored) { }
        }
    }

    private void disconnect() {
        stopScan();
        closeGatt();
        clearMeasurements();
        setStatus("Nicht verbunden", false);
    }

    /** BLE-Deskriptoren immer nacheinander schreiben: Android erlaubt nur eine GATT-Operation auf einmal. */
    private void subscribeNext(BluetoothGatt current) {
        if (current != gatt) return;
        while (subscribePosition < measurements.size()) {
            BluetoothGattCharacteristic ch = measurements.get(subscribePosition++);
            try {
                if (!current.setCharacteristicNotification(ch, true)) continue;
                BluetoothGattDescriptor ccc = ch.getDescriptor(CCC_UUID);
                if (ccc == null) continue;
                boolean started;
                if (Build.VERSION.SDK_INT >= 33) {
                    started = current.writeDescriptor(ccc, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) == BluetoothStatusCodes.SUCCESS;
                } else {
                    @SuppressWarnings("deprecation") boolean set = ccc.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    @SuppressWarnings("deprecation") boolean write = set && current.writeDescriptor(ccc);
                    started = write;
                }
                if (started) return; // Nächster Aufruf kommt über onDescriptorWrite.
            } catch (SecurityException ex) {
                break;
            }
        }
        readPosition = 0;
        readNext(current);
    }

    private void readNext(BluetoothGatt current) {
        if (current != gatt) return;
        while (readPosition < measurements.size()) {
            BluetoothGattCharacteristic ch = measurements.get(readPosition++);
            try {
                if (current.readCharacteristic(ch)) return;
            } catch (SecurityException ex) {
                break;
            }
        }
        runOnUiThread(() -> {
            if (connected) setStatus("Verbunden · Live-Messung", true);
        });
    }

    private void receive(UUID uuid, byte[] bytes) {
        if (bytes == null || bytes.length == 0) return;
        String raw = new String(bytes, StandardCharsets.UTF_8).trim();
        if (raw.isEmpty()) return;
        // Der ESP32 sendet bei Sensorfehler '--' statt einer Zahl.
        final String display;
        if (raw.equals("--")) {
            display = "– –";
        } else {
            try {
                double number = Double.parseDouble(raw.replace(',', '.'));
                if (!Double.isFinite(number)) return;
                display = String.format(Locale.GERMANY, uuid.equals(AW_UUID) ? "%.3f" : "%.1f", number);
            } catch (NumberFormatException exception) {
                return;
            }
        }
        runOnUiThread(() -> {
            if (!connected) return;
            if (uuid.equals(TEMP_UUID)) tempValue.setText(display);
            else if (uuid.equals(HUM_UUID)) humValue.setText(display);
            else if (uuid.equals(AW_UUID)) awValue.setText(display);
            lastValueAt = SystemClock.elapsedRealtime();
            String time = new SimpleDateFormat("HH:mm:ss", Locale.GERMANY).format(new Date());
            updatedText.setText("Letzte Aktualisierung: " + time + " Uhr");
        });
    }

    private void clearMeasurements() {
        lastValueAt = 0;
        runOnUiThread(() -> {
            tempValue.setText("– –");
            humValue.setText("– –");
            awValue.setText("– –");
            updatedText.setText("Noch keine Messwerte empfangen");
        });
    }

    private void setStatus(String message, boolean online) {
        runOnUiThread(() -> {
            statusText.setText(message);
            statusIcon.setTextColor(online ? GREEN : scanning ? YELLOW : MUTED);
            connectButton.setEnabled(!scanning && !connected && adapter != null);
            disconnectButton.setEnabled(scanning || connected || gatt != null);
            connectButton.setAlpha(connectButton.isEnabled() ? 1f : 0.55f);
            disconnectButton.setAlpha(disconnectButton.isEnabled() ? 1f : 0.55f);
        });
    }

    private int dp(float n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable bg(int fill, int stroke, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView text(String text, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setIncludeFontPadding(true);
        return v;
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private void addSpace(LinearLayout container, int height) {
        View space = new View(this);
        container.addView(space, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private TextView metricCard(LinearLayout parent, String title, String unit, String help, boolean primary) {
        LinearLayout card = column();
        card.setPadding(dp(20), dp(16), dp(20), dp(15));
        card.setBackground(bg(primary ? Color.rgb(23, 55, 68) : PANEL, primary ? Color.rgb(42, 125, 125) : OUTLINE, 20));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(12);
        parent.addView(card, params);
        card.addView(text(title, 15, Color.rgb(199, 219, 226), true));
        LinearLayout valueRow = new LinearLayout(this);
        valueRow.setOrientation(LinearLayout.HORIZONTAL);
        valueRow.setGravity(Gravity.BOTTOM);
        TextView number = text("– –", 58, primary ? CYAN : LIGHT, true);
        number.setSingleLine(true);
        number.setLetterSpacing(-0.04f);
        valueRow.addView(number, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView unitView = text(unit, 20, MUTED, true);
        unitView.setPadding(dp(3), 0, 0, dp(9));
        valueRow.addView(unitView);
        card.addView(valueRow);
        card.addView(text(help, 12, MUTED, false));
        return number;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTextColor(primary ? Color.rgb(7, 34, 41) : LIGHT);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(bg(primary ? CYAN : PANEL, primary ? CYAN : OUTLINE, 13));
        b.setMinHeight(dp(54));
        return b;
    }

    private void makeUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = column();
        root.setPadding(dp(18), dp(24), dp(18), dp(28));
        scroll.addView(root);
        setContentView(scroll);

        TextView head = text("Messkammer", 30, LIGHT, true);
        root.addView(head);
        root.addView(text("Live-Messwerte · ESP32-S3 · Bluetooth LE", 13, MUTED, false));
        addSpace(root, 21);

        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusRow.setPadding(dp(14), dp(14), dp(14), dp(14));
        statusRow.setBackground(bg(PANEL, OUTLINE, 13));
        statusIcon = text("●", 17, YELLOW, true);
        LinearLayout.LayoutParams circle = new LinearLayout.LayoutParams(-2, -2);
        circle.rightMargin = dp(11);
        statusRow.addView(statusIcon, circle);
        statusText = text("Nicht verbunden", 14, LIGHT, true);
        statusRow.addView(statusText);
        root.addView(statusRow);
        addSpace(root, 15);

        tempValue = metricCard(root, "🌡  Temperatur", "°C", "SHT45 · aktuelle Temperatur", true);
        humValue = metricCard(root, "💧  Luftfeuchtigkeit", "% rF", "Relative Feuchtigkeit in der Messkammer", false);
        awValue = metricCard(root, "◉  aw-Wert (geschätzt)", "aw", "Näherung aus Luftfeuchte ÷ 100", false);

        connectButton = button("Bluetooth verbinden", true);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(54));
        cp.topMargin = dp(7);
        root.addView(connectButton, cp);
        connectButton.setOnClickListener(view -> beginConnect());

        disconnectButton = button("Verbindung trennen", false);
        LinearLayout.LayoutParams dpv = new LinearLayout.LayoutParams(-1, dp(54));
        dpv.topMargin = dp(10);
        root.addView(disconnectButton, dpv);
        disconnectButton.setOnClickListener(view -> disconnect());
        disconnectButton.setEnabled(false);
        disconnectButton.setAlpha(0.55f);

        addSpace(root, 17);
        updatedText = text("Noch keine Messwerte empfangen", 13, MUTED, false);
        updatedText.setGravity(Gravity.CENTER);
        root.addView(updatedText);
        addSpace(root, 18);

        LinearLayout hint = column();
        hint.setPadding(dp(16), dp(13), dp(16), dp(14));
        hint.setBackground(bg(Color.rgb(18, 34, 52), OUTLINE, 15));
        hint.addView(text("So funktioniert es", 15, LIGHT, true));
        addSpace(hint, 6);
        hint.addView(text("1. ESP32-S3 mit der V9-INO einschalten.\n2. Am Handy auf „Bluetooth verbinden“ tippen.\n3. „Geräte in der Nähe“ erlauben.\n4. Temperatur, Feuchte und aw automatisch ablesen.", 13, MUTED, false));
        root.addView(hint);
        addSpace(root, 14);
        root.addView(text("Der aw-Wert ist nur eine Schätzung anhand der Luftfeuchte. Kein Nachweis für die Lebensmittelsicherheit.", 12, MUTED, false));
        setStatus("Nicht verbunden", false);
    }
}
