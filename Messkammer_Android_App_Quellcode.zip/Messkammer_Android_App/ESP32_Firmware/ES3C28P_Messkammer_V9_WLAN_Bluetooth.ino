// ES3C28P Messkammer V9: V8 plus Bluetooth Low Energy (BLE)
// WLAN, Touch-Kalibrierung, SHT45, Tastatur/Passwortanzeige bleiben erhalten.
// BLE Name: Messkammer-ES3C28P | Temperatur, rel. Feuchte, aw einzeln lesen/abonnieren.
// BLE ist direkt aktiv, auch ohne WLAN. Handy: nRF Connect -> Connect -> Read/Notify.
// Auf dem WLAN-Bildschirm wird nach OK angezeigt, ob die Eingabe im Flash gespeichert wurde.
// Touch-Kalibrierung, SHT45 und bisheriges Design bleiben erhalten.
// Passwort standardmaessig verdeckt; ANZEIGEN/VERBERGEN oben rechts.
// DEL: letztes Zeichen loeschen; ALLES: komplette Eingabe sofort leeren.
// Zeichenzahl wird immer angezeigt, auch bei Passwort mit mehr als 21 Zeichen.
// diymore ES3C28P, ESP32-S3, ILI9341V 240x320, FT6336G Touch
// Aenderungen gegenueber NEU:
//  1. Touch mit Flankenerkennung (ein Tippen = eine Aktion)
//  2. Tastatur zeichnet beim Tippen nur das Textfeld neu
//  3. Touch-Controller wird bei Ausfall alle 5 s erneut gesucht
//  4. WLAN: nur noch ein Wiederverbindungs-Mechanismus
//  5. Uhr und Datum (NTP, Mitteleuropaeische Zeit mit Sommerzeit)
//  6. Anzeige ohne Flackern (nur geaenderte Zeilen werden neu gezeichnet)
//  7. Touch: 3-Punkt-Kalibrierung, Speicherung im NVS, BOOT-Taste zum Neustart der Kalibrierung
// Erforderliche Libraries: Adafruit GFX, Adafruit ILI9341, Adafruit SHT4x
// BOARD: "ESP32S3 Dev Module", Flash 16MB, OPI PSRAM (falls N16R8).
// Hinweis: aw=rF/100 ist nur ein Gleichgewichts-Schaetzwert, keine Sicherheitsfreigabe.
// WLAN: nur 2.4 GHz; im Touch-Menue Netz suchen, Passwort eingeben und VERBINDEN.
// Bestehende Touch-Kalibrierung bleibt im NVS erhalten.

#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <time.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>
#include <Adafruit_SHT4x.h>
#include <Preferences.h>
#include <WiFi.h>
#include <WebServer.h>
// Bluetooth LE ist in der ESP32-Boardplattform enthalten (kein BluetoothSerial:
// ESP32-S3 unterstuetzt nur BLE, nicht Bluetooth Classic/SPP).
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <BLE2901.h>

// WLAN: Zugangsdaten hier oder spaeter ueber das Touch-Menue eintragen.
const char* WIFI_SSID = "MEIN_WLAN";
const char* WIFI_PASS = "MEIN_PASSWORT";

// Zeit: Mitteleuropa mit automatischer Sommerzeit
const char* TZ_INFO = "CET-1CEST,M3.5.0,M10.5.0/3";
const char* NTP_1 = "pool.ntp.org";
const char* NTP_2 = "time.nist.gov";

WebServer server(80);

// -------- Bluetooth LE: ausschliesslich Messwerte, KEINE WLAN-Zugangsdaten --------
// Alle Messwerte werden als kurze UTF-8-Texte uebertragen, damit Notifications
// auch bei der BLE-Standard-MTU von 23 Byte vollstaendig bleiben.
static const char* BLE_NAME="Messkammer-ES3C28P";
static const char* BLE_SERVICE_UUID="d7ae1000-d923-4d21-9842-3e8949210000";
static const char* BLE_TEMP_UUID   ="d7ae1001-d923-4d21-9842-3e8949210000";
static const char* BLE_HUM_UUID    ="d7ae1002-d923-4d21-9842-3e8949210000";
static const char* BLE_AW_UUID     ="d7ae1003-d923-4d21-9842-3e8949210000";
BLEServer* bleServer=nullptr;
BLECharacteristic* bleTemp=nullptr;
BLECharacteristic* bleHumidity=nullptr;
BLECharacteristic* bleAw=nullptr;
volatile bool bleConnected=false;
bool bleWasConnected=false;
int previousBleStatus=-1;

class MesskammerBLECallbacks : public BLEServerCallbacks {
 void onConnect(BLEServer* server) override {
  bleConnected=true;
  Serial.println("BLE: Handy verbunden");
 }
 void onDisconnect(BLEServer* server) override {
  bleConnected=false;
  Serial.println("BLE: Handy getrennt");
 }
};

BLECharacteristic* addMeasurement(BLEService* service, const char* uuid,
                                  const char* description) {
 BLECharacteristic* ch=service->createCharacteristic(
  uuid, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY);
 ch->addDescriptor(new BLE2902()); // Abonnieren (Notifications) im BLE-Scanner
 BLE2901* desc=new BLE2901();
 desc->setDescription(description);
 ch->addDescriptor(desc);
 ch->setValue("--");
 return ch;
}

void startBLE() {
 BLEDevice::init(BLE_NAME);
 bleServer=BLEDevice::createServer();
 bleServer->setCallbacks(new MesskammerBLECallbacks());
 BLEService* service=bleServer->createService(BLE_SERVICE_UUID);
 bleTemp=addMeasurement(service,BLE_TEMP_UUID,"Temperatur (Grad C)");
 bleHumidity=addMeasurement(service,BLE_HUM_UUID,"Relative Feuchte (% rF)");
 bleAw=addMeasurement(service,BLE_AW_UUID,"aw geschaetzt (rF / 100)");
 service->start();
 BLEAdvertising* advertising=BLEDevice::getAdvertising();
 advertising->addServiceUUID(BLE_SERVICE_UUID);
 advertising->setScanResponse(true);
 BLEDevice::startAdvertising();
 Serial.printf("BLE: %s ist sichtbar und bereit\n",BLE_NAME);
}

uint32_t lastWifiAttempt=0;
uint32_t wifiConnectStarted=0;
bool wifiConnecting=false;
String scannedSSIDs[5];
int scannedCount=0;

static constexpr int I2C_SDA=16, I2C_SCL=15;
static constexpr uint8_t TOUCH_ADDR=0x38;
static constexpr int TOUCH_RST=18, TOUCH_IRQ=17;
static constexpr int LCD_SCK=12, LCD_MISO=13, LCD_MOSI=11;
static constexpr int LCD_CS=10, LCD_DC=46, LCD_BL=45;

SPIClass lcdSPI(FSPI);
Adafruit_ILI9341 tft(&lcdSPI, LCD_DC, LCD_CS, -1);
Adafruit_SHT4x sht;
Preferences prefs;
bool sensorOK=false;
enum Screen { HOME_SCREEN, CAL_SCREEN, WIFI_SCREEN, KEYBOARD_SCREEN, TOUCH_CAL_SCREEN, SCAN_SCREEN };
Screen screen=HOME_SCREEN;
String wifiSSID, wifiPassword, editText;
bool editingPassword=false;
bool showPassword=false; // nur auf ausdruecklichen Tastendruck Klartext anzeigen
const char* keyboardRows[] = {"1234567890", "qwertyuiop", "asdfghjkl-", "zxcvbnm_.,"};
const char* symbolRows[]   = {"1234567890", "!@#$%^&*()", "-_=+[]{};:", ",./?\\|~<>+"};
bool keyboardUpper=false, keyboardSymbols=false;
String keyboardFeedback="";
String wifiSaveInfo="";
bool wifiSaveOK=true;
float rhOffset=0, tempOffset=0, tempC=NAN, humidity=NAN;
// Wird im 2-Sekunden-Messzyklus aufgerufen; Read und Notify verwenden
// dieselben Werte. Bei Ausfall meldet jede Charakteristik --.
void publishBLE() {
 if(!bleTemp || !bleHumidity || !bleAw)return;
 bool ok=sensorOK && isfinite(tempC) && isfinite(humidity);
 String t=ok?String(tempC,1):String("--");
 String h=ok?String(humidity,1):String("--");
 String a=ok?String(humidity/100.0f,3):String("--");
 bleTemp->setValue(t.c_str());
 bleHumidity->setValue(h.c_str());
 bleAw->setValue(a.c_str());
 if(bleConnected) {
  bleTemp->notify();
  bleHumidity->notify();
  bleAw->notify();
 }
}
uint32_t lastRead=0, lastTouch=0, lastTouchInit=0, lastClockTick=0;
bool touchInitOK=false;
// Affine Touch-Matrix: Display-X = a*RawX+b*RawY+c, Display-Y=d*RawX+e*RawY+f.
// Damit funktionieren auch vertauschte und gespiegelte Touch-Achsen.
float touchA=0, touchB=1, touchC=0, touchD=-1, touchE=0, touchF=239;
bool touchCalValid=false, touchAutoAttempted=false, ignoreTouchUntilRelease=false;
uint32_t bootHeldSince=0;
bool bootLongPressUsed=false;
const int touchTargetX[3]={40,280,40};
const int touchTargetY[3]={95,95,181};
int touchRawX[3]={0}, touchRawY[3]={0};
uint8_t touchCalStep=0;
uint32_t touchCalStepStarted=0;
bool touchCalWasDown=false;
Screen touchReturnScreen=HOME_SCREEN;
wl_status_t prevWifiStatus = WL_IDLE_STATUS;
// Farben in RGB565: dunkler Hintergrund und gut lesbare Akzentfarben
const uint16_t C_BG=0x08A3, C_CARD=0x1126, C_EDGE=0x2A6B;
const uint16_t C_HEADER=0x11C7, C_WHITE=0xFFFF, C_MUTED=0xA4F3;
const uint16_t C_TEAL=0x4F7A, C_BLUE=0x2D9F, C_YELLOW=0xFE08;
const uint16_t C_GREEN=0x668F, C_RED=0xF24C;
uint16_t bg=C_BG, fg=C_WHITE;

// Zwischenspeicher der Startseite (nur geaenderte Zeilen neu zeichnen)
String cClock, cLine1, cLine2, cLine3, cWifi;
int lastErrState=-1;

void centered(const String &s,int y,int size,uint16_t color){
 tft.setTextSize(size);tft.setTextColor(color,bg);int16_t x1,y1;uint16_t w,h;
 tft.getTextBounds(s,0,y,&x1,&y1,&w,&h);tft.setCursor((320-w)/2,y);tft.print(s);
}
void labelText(int x,int y,const String &s,int size,uint16_t color,uint16_t background){
 tft.setTextSize(size);tft.setTextColor(color,background);
 tft.setCursor(x,y);tft.print(s);
}
void card(int x,int y,int w,int h){
 tft.fillRoundRect(x,y,w,h,10,C_CARD);
 tft.drawRoundRect(x,y,w,h,10,C_EDGE);
}
void button(int x,int y,int w,int h,const String &s){
 tft.fillRoundRect(x,y,w,h,7,C_HEADER);
 tft.drawRoundRect(x,y,w,h,7,C_BLUE);
 int size=2;
 if((int)s.length()*12>w-8)size=1;
 int16_t bx,by;uint16_t bw,bh;
 tft.setTextSize(size);tft.getTextBounds(s,0,0,&bx,&by,&bw,&bh);
 tft.setTextColor(C_WHITE,C_HEADER);
 tft.setCursor(x+(w-(int)bw)/2,y+(h-(int)bh)/2);tft.print(s);
}
void primaryButton(int x,int y,int w,int h,const String &s){
 tft.fillRoundRect(x,y,w,h,8,C_BLUE);
 tft.setTextSize(2);tft.setTextColor(C_WHITE,C_BLUE);
 int16_t bx,by;uint16_t bw,bh;
 tft.getTextBounds(s,0,0,&bx,&by,&bw,&bh);
 tft.setCursor(x+(w-(int)bw)/2,y+(h-(int)bh)/2);tft.print(s);
}
// Kompatibilitaetshelfer fuer die alten Menues
void drawLine(const String &s,int y,int size,uint16_t col,String &cache){
 if(s==cache)return;
 tft.fillRect(0,y,320,size*8,bg);cache=s;centered(s,y,size,col);
}
void resetCaches(){cClock="";cLine1="";cLine2="";cLine3="";cWifi="";lastErrState=-1;previousBleStatus=-1;}

// ---------- Zeit ----------
bool timeValid(struct tm &t){
 if(!getLocalTime(&t,0))return false;
 return t.tm_year>=125; // ab 2025
}
String dateTimeString(){
 struct tm t;
 if(!timeValid(t))return "";
 char b[32];strftime(b,sizeof(b),"%d.%m.%Y  %H:%M:%S",&t);
 return String(b);
}
void drawClock(){
 if(screen!=HOME_SCREEN)return;
 struct tm t;
 String clockText="--:--";
 if(timeValid(t)){
  char b[8];strftime(b,sizeof(b),"%H:%M",&t);clockText=String(b);
 }
 if(clockText==cClock)return;
 cClock=clockText;
 tft.fillRect(240,14,68,17,C_HEADER);
 labelText(246,15,clockText,2,C_WHITE,C_HEADER);
}

// Kleine BLE-Statusanzeige oben: gelb = bereit, gruen = Handy verbunden.
void drawBLEStatus(){
 if(screen!=HOME_SCREEN)return;
 int state=bleConnected?1:0;
 if(state==previousBleStatus)return;
 previousBleStatus=state;
 tft.fillRect(169,14,47,18,C_HEADER);
 labelText(172,18,"BLE",1,C_WHITE,C_HEADER);
 tft.fillCircle(205,22,4,bleConnected?C_GREEN:C_YELLOW);
}

// ---------- Webseite ----------
String htmlPage(){
 String page = F("<!doctype html><html lang='de'><head><meta charset='utf-8'>"
 "<meta name='viewport' content='width=device-width,initial-scale=1'>"
 "<title>Schinken-Messkammer</title><style>body{font-family:Arial,sans-serif;"
 "background:#111827;color:#f9fafb;text-align:center;padding:20px}"
 "main{max-width:480px;margin:auto}.value{font-size:2.5em;margin:18px}"
 "small{color:#cbd5e1}</style></head><body><main><h2>Schinken-Messkammer</h2>"
 "<div id='values'>Messwerte werden geladen ...</div>"
 "<small>aw ist nur eine Schaetzung bei Feuchtegleichgewicht; keine Sicherheitsfreigabe.</small>"
 "</main><script>async function update(){try{const r=await fetch('/werte');"
 "const d=await r.json();document.getElementById('values').innerHTML="
 "d.ok?'<small>'+(d.zeit||'')+'</small><div class=\"value\">'+d.temperatur+' &deg;C</div><div class=\"value\">'+d.feuchte+' % rF</div><div class=\"value\">aw ca. '+d.aw+'</div>':"
 "'<p>Sensor nicht erreichbar</p>'; }catch(e){document.getElementById('values').textContent='Verbindung unterbrochen';}}"
 "update();setInterval(update,3000);</script></body></html>");
 return page;
}
void sendValues(){
 String json = "{\"ok\":";
 bool ok = sensorOK && isfinite(tempC) && isfinite(humidity);
 json += ok ? "true" : "false";
 if(ok){
  json += ",\"temperatur\":"+String(tempC,1)+",\"feuchte\":"+String(humidity,1)+",\"aw\":"+String(humidity/100.0f,3);
  String z=dateTimeString();
  if(z.length())json += ",\"zeit\":\""+z+"\"";
 }
 json += "}";
 server.send(200,"application/json; charset=utf-8",json);
}

// ---------- WLAN ----------
String wifiStatusText(){
 if(wifiSSID.length()==0)return "Kein Netz gespeichert";
 if(WiFi.status()==WL_CONNECTED)return "Verbunden";
 if(wifiConnecting)return "Verbindet ...";
 if(WiFi.status()==WL_NO_SSID_AVAIL)return "Netz nicht gefunden";
 if(WiFi.status()==WL_CONNECT_FAILED)return "Anmeldung fehlgeschl.";
 if(WiFi.status()==WL_CONNECTION_LOST)return "Verbindung verloren";
 return "Nicht verbunden";
}
void wifiMaintain(){
 if(wifiSSID.length()==0)return;
 WiFi.mode(WIFI_STA);
 WiFi.setSleep(false);
 // Ein bewusster Versuch: keine verschachtelten reconnect-Mechanismen.
 WiFi.disconnect(false,false);
 delay(70);
 WiFi.begin(wifiSSID.c_str(),wifiPassword.c_str());
 wifiConnecting=true;
 wifiConnectStarted=millis();
 lastWifiAttempt=millis();
 Serial.printf("WLAN: Verbindungsversuch mit SSID %s (Passwortlaenge %u)\n",
               wifiSSID.c_str(),(unsigned)wifiPassword.length());
}
String shortSSID(const String &ssid,int maxLen){
 if((int)ssid.length()<=maxLen)return ssid;
 return ssid.substring(0,maxLen-2)+"..";
}

// ---------- Bildschirme ----------
void home(){
 screen=HOME_SCREEN;tft.fillScreen(C_BG);resetCaches();
 tft.fillRoundRect(9,7,302,31,9,C_HEADER);
 labelText(20,15,"MESSKAMMER",2,C_WHITE,C_HEADER);
 drawBLEStatus();
 tft.fillCircle(226,23,4,sensorOK?C_GREEN:C_RED);
 card(9,45,147,73);card(164,45,147,73);card(9,126,302,55);
 labelText(20,55,"TEMPERATUR",1,C_MUTED,C_CARD);
 labelText(175,55,"LUFTFEUCHTE",1,C_MUTED,C_CARD);
 labelText(20,134,"aw-WERT (GESCHAETZT)",1,C_MUTED,C_CARD);
 labelText(166,151,"Nur im Gleichgewicht",1,C_MUTED,C_CARD);
 labelText(166,164,"keine Freigabe",1,C_MUTED,C_CARD);
 primaryButton(9,207,302,30,"EINSTELLUNGEN");
}
void redrawValues(){
 if(screen!=HOME_SCREEN)return;
 bool err=!sensorOK||!isfinite(tempC)||!isfinite(humidity);
 String t=err?"--.- C":String(tempC,1)+" C";
 String h=err?"--.- %":String(humidity,1)+" %";
 String a=err?"--.---":String(humidity/100.0f,3);
 if(t!=cLine1){
  cLine1=t;tft.fillRect(18,73,130,36,C_CARD);
  labelText(18,76,t,3,err?C_RED:C_YELLOW,C_CARD);
 }
 if(h!=cLine2){
  cLine2=h;tft.fillRect(173,73,130,36,C_CARD);
  labelText(173,76,h,3,err?C_RED:C_TEAL,C_CARD);
 }
 if(a!=cLine3){
  cLine3=a;tft.fillRect(18,149,127,26,C_CARD);
  labelText(18,150,a,3,err?C_RED:C_GREEN,C_CARD);
 }
 String status;
 if(WiFi.status()==WL_CONNECTED){
  status="WLAN: "+WiFi.localIP().toString();
 }else if(wifiConnecting)status="WLAN: Verbindung wird aufgebaut";
 else status="WLAN: "+wifiStatusText();
 if(status!=cWifi){
  cWifi=status;tft.fillRect(9,185,302,16,C_BG);
  labelText(13,188,shortSSID(status,48),1,
            WiFi.status()==WL_CONNECTED?C_GREEN:C_MUTED,C_BG);
 }
}
void settingsPage(){
 screen=CAL_SCREEN;tft.fillScreen(C_BG);
 centered("EINSTELLUNGEN",8,2,C_TEAL);
 centered("Sensor-Abgleich",38,2,C_MUTED);
 char line[50];snprintf(line,sizeof(line),"Feuchte: %+.1f %%",rhOffset);
 centered(line,69,2,C_WHITE);
 button(20,100,130,42,"rF -0.5");button(170,100,130,42,"rF +0.5");
 snprintf(line,sizeof(line),"Temp: %+.1f C",tempOffset);centered(line,149,2,C_WHITE);
 button(20,176,130,32,"T -0.1");button(170,176,130,32,"T +0.1");
 button(7,211,91,27,"WLAN");button(106,211,94,27,"TOUCH");button(208,211,105,27,"ZURUECK");
}
void wifiPage(){
 screen=WIFI_SCREEN;tft.fillScreen(C_BG);
 centered("WLAN-EINSTELLUNGEN",8,2,C_TEAL);
 card(9,34,302,51);
 labelText(18,41,"VERBINDUNGSSTATUS",1,C_MUTED,C_CARD);
 String s=wifiStatusText();
 labelText(18,53,shortSSID(s,24),2,
           WiFi.status()==WL_CONNECTED?C_GREEN:(wifiConnecting?C_YELLOW:C_RED),C_CARD);
 String detail=(WiFi.status()==WL_CONNECTED)?
   ("IP "+WiFi.localIP().toString()+" / "+String(WiFi.RSSI())+" dBm"):
   (wifiConnecting?"Bitte bis zu 20 Sekunden warten":"Nur 2.4 GHz / WPA2 empfohlen");
 labelText(18,74,shortSSID(detail,47),1,C_MUTED,C_CARD);
 card(9,90,302,43);
 labelText(18,96,"GEWAEHLTES NETZWERK",1,C_MUTED,C_CARD);
 labelText(18,111,shortSSID(wifiSSID.length()==0?String("(noch keines)"):wifiSSID,23),2,C_WHITE,C_CARD);
 button(9,138,147,29,"NAME AENDERN");button(164,138,147,29,"PASSWORT");
 button(9,174,95,32,"SUCHEN");button(112,174,98,32,"VERBINDEN");button(218,174,93,32,"ZURUECK");
 // Die obere Zeile zeigt die Rueckmeldung von OK, die untere den echten Speicherstand.
 if(wifiSaveInfo.length())labelText(13,211,shortSSID(wifiSaveInfo,49),1,wifiSaveOK?C_GREEN:C_RED,C_BG);
 else labelText(13,211,"OK = SPEICHERN   VERBINDEN = STARTEN",1,C_MUTED,C_BG);
 labelText(13,225,"Gespeichertes Passwort: "+String((unsigned)wifiPassword.length())+" Zeichen",1,C_MUTED,C_BG);
}
void scanPage(){
 screen=SCAN_SCREEN;tft.fillScreen(C_BG);
 centered("WLAN AUSWAEHLEN",6,2,C_TEAL);
 centered("Nur 2.4-GHz-Netze sichtbar",28,1,C_MUTED);
 for(int i=0;i<scannedCount;i++){
  int y=42+i*31;
  button(9,y,302,28,shortSSID(scannedSSIDs[i],28));
 }
 if(scannedCount==0)centered("Keine Netze gefunden",99,2,C_RED);
 button(9,205,302,32,"ZURUECK");
}
void scanWifi(){
 screen=SCAN_SCREEN;tft.fillScreen(C_BG);
 centered("SUCHE WLAN ...",80,2,C_TEAL);
 int count=WiFi.scanNetworks(false,false);
 scannedCount=0;
 if(count>0){
  for(int i=0;i<count && scannedCount<5;i++){
   String name=WiFi.SSID(i);
   if(name.length()==0)continue;
   bool dupe=false;
   for(int j=0;j<scannedCount;j++)if(scannedSSIDs[j]==name)dupe=true;
   if(!dupe)scannedSSIDs[scannedCount++]=name;
  }
 }
 WiFi.scanDelete();scanPage();
}

// ---------- Tastatur ----------
char keyAt(int row, int col) {
 char ch = (keyboardSymbols ? symbolRows[row][col] : keyboardRows[row][col]);
 if (!keyboardSymbols && keyboardUpper && ch >= 'a' && ch <= 'z') ch -= ('a' - 'A');
 return ch;
}
// Immer das Eingabefeld plus den tatsaechlichen Zeichenzahler aktualisieren.
// Passwort standardmaessig maskieren; auf Wunsch per ANZEIGEN sichtbar.
void drawKeyField(){
 tft.fillRect(5,29,310,25,C_CARD);
 String visible;
 if(editingPassword && !showPassword){
  for(size_t i=0;i<editText.length();i++)visible+='*';
 }else visible=editText;
 tft.setTextColor(C_WHITE,C_CARD);
 if(editingPassword && showPassword && visible.length()>20){
  // Beim Anzeigen auch lange Passwoerter komplett darstellen (bis 63 Zeichen).
  // Bis 40 Zeichen in der ersten und weitere 23 in der zweiten Zeile.
  tft.setTextSize(1);
  tft.setCursor(9,30);tft.print(visible.substring(0,40));
  tft.setCursor(9,42);tft.print(visible.substring(40));
 }else{
  if(visible.length()>20)visible=visible.substring(visible.length()-20);
  tft.setTextSize(2);
  tft.setCursor(9,33);tft.print(visible);
 }
 // Zeichenzahl bleibt sichtbar, selbst wenn im verdeckten Modus nur die letzten
 // 20 Sterne angezeigt werden.
 tft.fillRect(262,30,52,22,C_EDGE);
 tft.setTextSize(1);tft.setTextColor(C_YELLOW,C_EDGE);
 tft.setCursor(268,37);tft.print(String(editText.length())+"/63");
}
void keyFeedback(const String &s){
 keyboardFeedback=s;
 // Statuszeile links, damit sie niemals unter ANZEIGEN/VERBERGEN liegt.
 tft.fillRect(0,21,203,8,C_BG);
 tft.setTextSize(1);tft.setTextColor(C_GREEN,C_BG);
 tft.setCursor(8,21);
 tft.print(keyboardFeedback.substring(0,32));
}
void keyButton(int x,int y,int w,int h,const char *name,uint16_t color){
 tft.fillRoundRect(x,y,w,h,5,color);
 tft.drawRoundRect(x,y,w,h,5,C_WHITE);
 int size=((int)strlen(name)*12<=w-6)?2:1;
 int16_t bx,by;uint16_t bw,bh;
 tft.setTextSize(size);
 tft.getTextBounds(name,0,0,&bx,&by,&bw,&bh);
 tft.setTextColor(C_WHITE,color);
 tft.setCursor(x+(w-(int)bw)/2,y+(h-(int)bh)/2);
 tft.print(name);
}
void passwordToggleButton(){
 if(!editingPassword)return;
 keyButton(205,1,113,25,showPassword?"VERBERGEN":"ANZEIGEN",C_HEADER);
}
void keyboardPage(bool password){
 screen=KEYBOARD_SCREEN;editingPassword=password;
 tft.fillScreen(bg);
 // Titel links statt mittig, damit der Passwort-Schalter Platz hat.
 labelText(7,3,password?"WLAN-PASSWORT":"WLAN-NAME",2,C_TEAL,C_BG);
 passwordToggleButton();
 drawKeyField();
 keyFeedback("DEL=1 Zeich. ALLES=Leeren");
 // 4 Buchstabenreihen: 54-174; darunter zwei grosse Funktionstastenreihen.
 for(int r=0;r<4;r++)for(int c=0;c<10;c++){
  int x=2+c*32,y=54+r*30;
  tft.drawRoundRect(x,y,30,28,3,C_BLUE);
  tft.setTextColor(C_WHITE,bg);tft.setTextSize(2);
  tft.setCursor(x+8,y+6);tft.print(keyAt(r,c));
 }
 // Erste Reihe: Umschalten, Symbole, Leerzeichen, Abbrechen.
 keyButton(0,177,63,30,"a/A",C_HEADER);
 keyButton(65,177,63,30,"SYM",C_HEADER);
 keyButton(130,177,63,30,"LEER",C_HEADER);
 keyButton(195,177,125,30,"ABBR",C_HEADER);
 // Zweite Reihe: grosse, eindeutig getrennte Loesch- und Speichertasten.
 keyButton(0,210,102,30,"ALLES",C_RED);
 keyButton(105,210,105,30,"DEL",C_RED);
 keyButton(213,210,107,30,"OK",C_GREEN);
}
void handleKeyboard(int x,int y){
 // Passwort auf Wunsch einblenden. Kein erneuter Aufruf der Tastatur noetig,
 // daher bleibt die bisherige Eingabe bei ANZEIGEN/VERBERGEN erhalten.
 if(editingPassword && y>=0 && y<29 && x>=205){
  showPassword=!showPassword;
  passwordToggleButton();
  drawKeyField();
  keyFeedback(showPassword?"Passwort sichtbar":"Passwort verdeckt");
  return;
 }
 if(y>=54 && y<174){
  int row=(y-54)/30,col=x/32;
  if(row>=0 && row<4 && col>=0 && col<10 && editText.length()<63){
   editText+=keyAt(row,col);
   drawKeyField();
   keyFeedback("Eingabe: "+String(editText.length())+" Zeichen");
  }
 }else if(y>=177 && y<208){
  if(x<65){keyboardUpper=!keyboardUpper;keyboardPage(editingPassword);}
  else if(x<130){keyboardSymbols=!keyboardSymbols;keyboardPage(editingPassword);}
  else if(x<195){
   if(editText.length()<63)editText+=' ';
   drawKeyField();keyFeedback("Eingabe: "+String(editText.length())+" Zeichen");
  }else{showPassword=false;wifiPage();} // ABBR: Eingabe verwerfen, gespeicherte Daten bleiben unveraendert
 }else if(y>=210 && y<240){
  if(x<104){ // ALLES: die ganze aktuell bearbeitete Eingabe loeschen
   editText="";
   drawKeyField();keyFeedback("ALLES: 0 Zeichen");
   Serial.println("Tastatur ALLES: 0 Zeichen");
  }else if(x<213){ // DEL: letztes Zeichen entfernen, kein langes Druecken erforderlich
   if(editText.length()>0)editText.remove(editText.length()-1);
   drawKeyField();
   keyFeedback("DEL: "+String(editText.length())+" Zeichen uebrig");
   Serial.printf("Tastatur DEL: %u Zeichen uebrig\n",(unsigned)editText.length());
  }else{ // OK: Eingabe uebernehmen und in NVS speichern
   if(editingPassword){
    wifiPassword=editText;
    prefs.putString("pass",wifiPassword);
    wifiSaveOK=(prefs.getString("pass", "__NICHT_GEFUNDEN__")==wifiPassword);
    wifiSaveInfo=wifiSaveOK?
      ("PASSWORT GESPEICHERT ("+String((unsigned)wifiPassword.length())+" Zeichen)"):
      String("FEHLER: PASSWORT NICHT GESPEICHERT");
   }else{
    if(wifiSSID!=editText){
     wifiPassword="";
     WiFi.disconnect(false,false);
     wifiConnecting=false;
     prefs.putString("pass",wifiPassword);
    }
    wifiSSID=editText;
    prefs.putString("ssid",wifiSSID);
    wifiSaveOK=(prefs.getString("ssid", "__NICHT_GEFUNDEN__")==wifiSSID);
    wifiSaveInfo=wifiSaveOK?String("WLAN-NAME GESPEICHERT"):
                        String("FEHLER: WLAN-NAME NICHT GESPEICHERT");
   }
   Serial.printf("WLAN-Eingabe OK: %s, gespeichert=%s, Zeichen=%u\n",
      editingPassword?"Passwort":"Name",wifiSaveOK?"ja":"nein",(unsigned)editText.length());
   wifiPage();
  }
 }
}

// ---------- Touch ----------
bool touchProbe(){
 Wire.beginTransmission(TOUCH_ADDR);
 return Wire.endTransmission()==0;
}
// FT6336G: 0x02 = Anzahl Finger; 0x03..0x06 = rohe X/Y-Koordinaten.
// Beim Kalibrieren bewusst KEINE feste Drehung oder Spiegelung anwenden.
bool getTouchRaw(int &rawX,int &rawY){
 if(!touchInitOK)return false;
 Wire.beginTransmission(TOUCH_ADDR);
 Wire.write((uint8_t)0x02);
 if(Wire.endTransmission(false)!=0)return false;
 if(Wire.requestFrom(TOUCH_ADDR,(uint8_t)5)!=(uint8_t)5)return false;
 uint8_t n=Wire.read();
 uint8_t xh=Wire.read(),xl=Wire.read(),yh=Wire.read(),yl=Wire.read();
 if((n&0x0F)==0 || (n&0x0F)>2)return false;
 rawX=((xh&0x0F)<<8)|xl;
 rawY=((yh&0x0F)<<8)|yl;
 if(rawX>4095 || rawY>4095)return false;
 return true;
}
bool getTouch(int &x,int &y){
 int rawX=0,rawY=0;
 if(!getTouchRaw(rawX,rawY))return false;
 float fx=touchA*rawX+touchB*rawY+touchC;
 float fy=touchD*rawX+touchE*rawY+touchF;
 if(!isfinite(fx)||!isfinite(fy))return false;
 x=constrain((int)lroundf(fx),0,319);
 y=constrain((int)lroundf(fy),0,239);
 return true;
}
void readSavedTouchCalibration(){
 touchCalValid=prefs.getBool("touchvalid",false);
 if(!touchCalValid)return;
 touchA=prefs.getFloat("ta",0);touchB=prefs.getFloat("tb",1);
 touchC=prefs.getFloat("tcx",0);touchD=prefs.getFloat("td",-1);
 touchE=prefs.getFloat("te",0);touchF=prefs.getFloat("tf",239);
 float determinant=touchA*touchE-touchB*touchD;
 if(!isfinite(determinant)||fabsf(determinant)<0.05f){
  touchCalValid=false;
  touchA=0;touchB=1;touchC=0;touchD=-1;touchE=0;touchF=239;
 }
}
void drawTouchCalibration(){
 tft.fillScreen(bg);
 centered("TOUCH KALIBRIEREN",5,2,ILI9341_CYAN);
 centered("Punkt "+String(touchCalStep+1)+" von 3 antippen",33,2,fg);
 centered("Genau die Mitte des Kreuzes",55,1,fg);
 int x=touchTargetX[touchCalStep],y=touchTargetY[touchCalStep];
 tft.drawCircle(x,y,14,ILI9341_YELLOW);
 tft.drawFastHLine(x-22,y,45,ILI9341_YELLOW);
 tft.drawFastVLine(x,y-22,45,ILI9341_YELLOW);
 tft.fillCircle(x,y,3,ILI9341_RED);
 centered("25 Sekunden je Punkt",210,1,fg);
 centered("Ohne Touch: zurueck zur Anzeige",224,1,fg);
 touchCalStepStarted=millis();
}
void beginTouchCalibration(Screen backTo){
 if(!touchInitOK)return;
 touchReturnScreen=backTo;
 screen=TOUCH_CAL_SCREEN;
 touchCalStep=0;touchCalWasDown=true; // erst loslassen, dann neu antippen
 drawTouchCalibration();
 Serial.println("TOUCH-KALIBRIERUNG: 3 Kreuze antippen");
}
void endTouchCalibration(){
 ignoreTouchUntilRelease=true;
 if(touchReturnScreen==CAL_SCREEN)settingsPage();
 else{home();redrawValues();drawClock();}
}
void handleTouchCalibration(){
 if(millis()-touchCalStepStarted>25000UL){
  Serial.println("Touch-Kalibrierung: Zeit abgelaufen, bisherige Zuordnung bleibt");
  endTouchCalibration();return;
 }
 int rx=0,ry=0;
 bool down=getTouchRaw(rx,ry);
 if(!down){touchCalWasDown=false;return;}
 if(touchCalWasDown)return;
 touchCalWasDown=true;
 Serial.printf("Kalibrierpunkt %u: RawX=%d RawY=%d\n",touchCalStep+1,rx,ry);
 touchRawX[touchCalStep]=rx;touchRawY[touchCalStep]=ry;
 touchCalStep++;
 if(touchCalStep<3){drawTouchCalibration();return;}
 // Aus drei verschiedenen Punkten wird eine 2D-Affintransformation bestimmt.
 float ux=touchRawX[1]-touchRawX[0], uy=touchRawY[1]-touchRawY[0];
 float vx=touchRawX[2]-touchRawX[0], vy=touchRawY[2]-touchRawY[0];
 float det=ux*vy-uy*vx;
 if(fabsf(det)<5000.0f){
  Serial.println("Kalibrierpunkte unplausibel: bitte erneut versuchen");
  tft.fillScreen(bg);
  centered("KALIBRIERUNG FEHLER",70,2,ILI9341_RED);
  centered("Bitte erneut antippen",108,2,fg);
  delay(1400);
  touchCalStep=0;touchCalWasDown=true;
  drawTouchCalibration();return;
 }
 float dx1=touchTargetX[1]-touchTargetX[0];
 float dx2=touchTargetX[2]-touchTargetX[0];
 float dy1=touchTargetY[1]-touchTargetY[0];
 float dy2=touchTargetY[2]-touchTargetY[0];
 float a=(dx1*vy-dx2*uy)/det;
 float b=(-dx1*vx+dx2*ux)/det;
 float d=(dy1*vy-dy2*uy)/det;
 float e=(-dy1*vx+dy2*ux)/det;
 float c=touchTargetX[0]-a*touchRawX[0]-b*touchRawY[0];
 float f=touchTargetY[0]-d*touchRawX[0]-e*touchRawY[0];
 if(!isfinite(a)||!isfinite(b)||!isfinite(c)||!isfinite(d)||!isfinite(e)||!isfinite(f)){
  Serial.println("Touch-Kalibrierung: ungueltige Matrix");
  touchCalStep=0;touchCalWasDown=true;drawTouchCalibration();return;
 }
 touchA=a;touchB=b;touchC=c;touchD=d;touchE=e;touchF=f;
 prefs.putFloat("ta",a);prefs.putFloat("tb",b);prefs.putFloat("tcx",c);
 prefs.putFloat("td",d);prefs.putFloat("te",e);prefs.putFloat("tf",f);
 prefs.putBool("touchvalid",true);
 touchCalValid=true;
 Serial.printf("Touch gespeichert: X=%.3f*rx+%.3f*ry+%.1f Y=%.3f*rx+%.3f*ry+%.1f\n",a,b,c,d,e,f);
 tft.fillScreen(bg);
 centered("TOUCH GESPEICHERT",88,2,ILI9341_GREEN);
 delay(900);
 endTouchCalibration();
}
void save(){prefs.putFloat("rh",rhOffset);prefs.putFloat("tc",tempOffset);}

bool sensorBegin(){
 bool ok=sht.begin(&Wire);
 if(ok){sht.setPrecision(SHT4X_HIGH_PRECISION);sht.setHeater(SHT4X_NO_HEATER);}
 return ok;
}

void setup(){
 Serial.begin(115200);
 delay(250);
 Serial.println("ES3C28P - Messkammer V9: V8 + WLAN + BLE + Touch");
 pinMode(LCD_BL,OUTPUT);
 digitalWrite(LCD_BL,HIGH);
 lcdSPI.begin(LCD_SCK,LCD_MISO,LCD_MOSI,LCD_CS);
 tft.begin(27000000);
 tft.setRotation(1); // 320 x 240

 pinMode(TOUCH_RST,OUTPUT);
 digitalWrite(TOUCH_RST,LOW);
 delay(15);
 digitalWrite(TOUCH_RST,HIGH);
 delay(250);
 pinMode(TOUCH_IRQ,INPUT);
 pinMode(0,INPUT_PULLUP); // BOOT-Taste: 3 Sekunden halten fuer Touch-Kalibrierung
 Wire.begin(I2C_SDA,I2C_SCL);
 Wire.setClock(100000);
 touchInitOK=touchProbe();
 Serial.printf("FT6336G (0x38): %s\n",touchInitOK?"gefunden":"NICHT gefunden");

 prefs.begin("messkammer",false);
 rhOffset=prefs.getFloat("rh",0);tempOffset=prefs.getFloat("tc",0);
 readSavedTouchCalibration();
 wifiSSID=prefs.getString("ssid",String(WIFI_SSID)=="MEIN_WLAN"?"":WIFI_SSID);
 wifiPassword=prefs.getString("pass",String(WIFI_PASS)=="MEIN_PASSWORT"?"":WIFI_PASS);
 sensorOK=sensorBegin();
 Serial.printf("SHT45 (0x44): %s\n",sensorOK?"gefunden":"NICHT gefunden");

 WiFi.mode(WIFI_STA);
 WiFi.setAutoReconnect(false);
 WiFi.setSleep(false);
 wifiMaintain();
 configTzTime(TZ_INFO,NTP_1,NTP_2); // NTP startet, sobald WLAN verbunden ist
 server.on("/",HTTP_GET,[](){server.send(200,"text/html; charset=utf-8",htmlPage());});
 server.on("/werte",HTTP_GET,sendValues);
 server.begin();
 startBLE(); // BLE parallel zu WLAN; auch ohne WLAN sofort nutzbar.
 publishBLE(); // Anfänglicher Wert ist per READ verfuegbar.
 home();redrawValues();drawClock();
 // Ohne gespeicherte Touch-Zuordnung beim ersten Start automatisch kalibrieren.
 if(touchInitOK && !touchCalValid){
  touchAutoAttempted=true;
  beginTouchCalibration(HOME_SCREEN);
 }
}

void loop(){
 server.handleClient();
 // Nach einer Trennung wieder fuer Handys sichtbar werden.
 if(!bleConnected && bleWasConnected){
  delay(100);
  if(bleServer)bleServer->startAdvertising();
  bleWasConnected=false;
  Serial.println("BLE: erneute Suche moeglich");
 }else if(bleConnected && !bleWasConnected){
  bleWasConnected=true;
 }
 drawBLEStatus();

 // WLAN: Status und Verbindungsversuche ohne reconnect-Schleife.
 wl_status_t status=WiFi.status();
 if(status==WL_CONNECTED)wifiConnecting=false;
 if(wifiConnecting && millis()-wifiConnectStarted>20000UL)wifiConnecting=false;
 if(status!=WL_CONNECTED && !wifiConnecting && wifiSSID.length()!=0 &&
    millis()-lastWifiAttempt>45000UL && screen!=KEYBOARD_SCREEN && screen!=SCAN_SCREEN){
  wifiMaintain();
 }
 static bool oldConnecting=false;
 if(status!=prevWifiStatus || wifiConnecting!=oldConnecting){
  prevWifiStatus=status;oldConnecting=wifiConnecting;
  Serial.printf("WLAN: Status %d, verbinde=%d\n",(int)status,(int)wifiConnecting);
  redrawValues();
  if(screen==WIFI_SCREEN)wifiPage();
 }

 // Touch-Controller erneut suchen, falls er beim Start fehlte
 if(!touchInitOK && millis()-lastTouchInit>5000){
  lastTouchInit=millis();
  touchInitOK=touchProbe();
  if(touchInitOK){
   Serial.println("FT6336G jetzt gefunden");
   if(!touchCalValid && !touchAutoAttempted){
    touchAutoAttempted=true;beginTouchCalibration(HOME_SCREEN);
   }
  }
 }

 // Sensor
 if(millis()-lastRead>=2000 || lastRead==0){
  lastRead=millis();
  if(!sensorOK){
   sensorOK=sensorBegin();
   if(sensorOK)Serial.println("SHT45 wieder verbunden");
  }
  if(sensorOK){sensors_event_t h,t;
   if(sht.getEvent(&h,&t)){tempC=t.temperature+tempOffset;humidity=constrain(h.relative_humidity+rhOffset,0.0f,100.0f);}
   else{tempC=NAN;humidity=NAN; sensorOK=false;}
  }
  redrawValues();
  publishBLE();
 }

 // Uhr (nur bei Aenderung wird neu gezeichnet)
 if(millis()-lastClockTick>=250){lastClockTick=millis();drawClock();}

 // BOOT-Taste (GPIO0) fuer mindestens 3 Sekunden gedrueckt halten:
 // Kalibrierung auch dann starten, wenn die Bildschirm-Buttons nicht funktionieren.
 if(digitalRead(0)==LOW){
  if(!bootHeldSince)bootHeldSince=millis();
  if(!bootLongPressUsed && screen!=TOUCH_CAL_SCREEN && touchInitOK &&
     millis()-bootHeldSince>=3000UL){
   bootLongPressUsed=true;
   beginTouchCalibration(HOME_SCREEN);
  }
 }else{bootHeldSince=0;bootLongPressUsed=false;}

 // Kalibrierung liest die ROHEN Touch-Koordinaten, nicht die alten Bildschirmwerte.
 if(screen==TOUCH_CAL_SCREEN){handleTouchCalibration();delay(10);return;}

 // Touch mit Flankenerkennung: ein Tippen loest genau eine Aktion aus
 static bool wasDown=false;
 int x=0,y=0;
 bool down=getTouch(x,y);
 if(ignoreTouchUntilRelease){
  wasDown=down;
  if(!down)ignoreTouchUntilRelease=false;
  delay(10);return;
 }
 bool pressed=down && !wasDown;
 wasDown=down;
 if(pressed && millis()-lastTouch>40){
  lastTouch=millis();
  if(screen==HOME_SCREEN){if(x>=9 && x<=311 && y>=207 && y<=238)settingsPage();}
  else if(screen==CAL_SCREEN){
   if(y>=100 && y<=142 && ((x>=20 && x<=150)||(x>=170 && x<=300))){if(x<160)rhOffset-=0.5f;else rhOffset+=0.5f;save();settingsPage();}
   else if(y>=176 && y<=208 && ((x>=20 && x<=150)||(x>=170 && x<=300))){if(x<160)tempOffset-=0.1f;else tempOffset+=0.1f;save();settingsPage();}
   else if(y>=211){
    if(x<102)wifiPage();
    else if(x<204)beginTouchCalibration(CAL_SCREEN);
    else{home();redrawValues();drawClock();}
   }
  }
  else if(screen==WIFI_SCREEN){
   if(y>=138 && y<=167){
    if(x<160){editText=wifiSSID;showPassword=false;keyboardSymbols=false;keyboardUpper=false;keyboardPage(false);}
    else{editText=wifiPassword;showPassword=false;keyboardSymbols=false;keyboardUpper=false;keyboardPage(true);}
   }
   else if(y>=174 && y<=206){
    if(x<108)scanWifi();
    else if(x<215){wifiMaintain();wifiPage();}
    else settingsPage();
   }
  }
  else if(screen==SCAN_SCREEN){
   if(y>=205){wifiPage();}
   else if(y>=42 && y<42+scannedCount*31){
    int index=(y-42)/31;
    if(index>=0 && index<scannedCount){
     String newSSID=scannedSSIDs[index];
     if(newSSID!=wifiSSID){wifiPassword="";WiFi.disconnect(false,false);wifiConnecting=false;} // Passwort nur fuer gewaehltes Netz gueltig
     wifiSSID=newSSID;
     prefs.putString("ssid",wifiSSID);
     prefs.putString("pass",wifiPassword);
     wifiPage();
    }
   }
  }
  else if(screen==KEYBOARD_SCREEN)handleKeyboard(x,y);
 }
 delay(10);
}
